package com.example.service;

import com.example.entity.College;

public interface CollegeService {

	College saveAdmin(College admin);

}
