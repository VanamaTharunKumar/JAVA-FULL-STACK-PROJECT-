package com.tnsif.day5.packages.package1;

public class A {
	
	public void displayA(){
		System.out.println("DisplayA method from class A");
	}

}
