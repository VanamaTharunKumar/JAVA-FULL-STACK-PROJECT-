package com.tnsif.day5.supervariable;

public class Animal {
	
	String color = "White";

}
