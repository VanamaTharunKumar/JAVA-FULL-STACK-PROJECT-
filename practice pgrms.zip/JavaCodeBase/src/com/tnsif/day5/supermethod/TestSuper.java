package com.tnsif.day5.supermethod;

public class TestSuper {
	
	public static void main(String[] args) {
		B b1 = new B();
		b1.work();
	}

}
