package com.tnsif.day5.superconstructor;

public class TestSuper3 {
	
	public static void main(String[] args) {
		Dog d1 = new Dog();
		
	}

}
