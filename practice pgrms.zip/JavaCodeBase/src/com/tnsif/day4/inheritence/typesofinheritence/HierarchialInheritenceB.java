package com.tnsif.day4.inheritence.typesofinheritence;

public class HierarchialInheritenceB extends HierarchialInheritenceA {
	
	public void print() {
		System.out.println("I am a method from class B");
	}

}
