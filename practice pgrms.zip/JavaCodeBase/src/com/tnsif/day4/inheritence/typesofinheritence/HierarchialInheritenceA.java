package com.tnsif.day4.inheritence.typesofinheritence;

public class HierarchialInheritenceA {
	
	public void display() {
		System.out.println("I am method from class A");
	}

}

