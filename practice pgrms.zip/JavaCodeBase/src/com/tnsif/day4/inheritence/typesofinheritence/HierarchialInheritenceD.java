package com.tnsif.day4.inheritence.typesofinheritence;

public class HierarchialInheritenceD extends HierarchialInheritenceA{
	
	public void output() {
		System.out.println("I am a method from class D");
	}

}
