package com.tnsif.day4.inheritence.typesofpolymorphism;

public class PolymorphismLanguage1MOverriding {
	
	public void displayInfo() {
	    System.out.println("Common English Language");
	  }

}
