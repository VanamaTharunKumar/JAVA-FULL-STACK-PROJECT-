package com.tnsif.day4.inheritence.typesofpolymorphism;

public class PolymorphismLanguage1ExtendsMOverriding extends PolymorphismLanguage1MOverriding {
	
	@Override
	  public void displayInfo() {
	    System.out.println("Java Programming Language");
	  }

}
