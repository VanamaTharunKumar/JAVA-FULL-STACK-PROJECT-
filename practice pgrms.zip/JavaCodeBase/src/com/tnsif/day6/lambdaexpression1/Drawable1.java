package com.tnsif.day6.lambdaexpression1;

public interface Drawable1 {
	
	public void draw();

}
