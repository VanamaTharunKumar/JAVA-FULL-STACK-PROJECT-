package com.tnsif.day6.lambdaexpression3;

public interface Addable {
	
    int add(int a,int b);  

}
