package com.tnsif.day6interfaces.multipleinheritence;

public interface Bank {
	
	float rateofInterest();

}
