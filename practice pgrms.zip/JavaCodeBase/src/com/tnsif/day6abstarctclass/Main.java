package com.tnsif.day6abstarctclass;

public class Main {
	
	public static void main(String[] args) {
		Base b1 = new Derived();
		b1.fun();
	}

}
