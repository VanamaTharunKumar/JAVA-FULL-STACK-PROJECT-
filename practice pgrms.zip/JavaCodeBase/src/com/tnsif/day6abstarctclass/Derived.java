package com.tnsif.day6abstarctclass;

public class Derived extends Base{

	@Override
	void fun() {
		// TODO Auto-generated method stub
		
		System.out.println("Derived fun() method called");
		
	}

}
